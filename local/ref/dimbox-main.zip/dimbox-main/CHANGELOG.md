# Change Log
This is the changelog for [DimBox](https://xxxxx).

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/)
and this project adheres to [Semantic Versioning](http://semver.org/).

## [1.0.2] - 2023-05-29
### Changed
- Add init to public methods.

## [1.0.1] - 2023-02-03
### Added
- Add repository to package.json.

## [1.0.0] - 2023-01-03
- First release.
